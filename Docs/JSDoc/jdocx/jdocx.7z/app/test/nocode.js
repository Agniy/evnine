/**#nocode+*/
    /**
      @name star
      @function
    */
    function blahblah() {
    
    }
/**#nocode-*/

function yaddayadda() {

}